<?php
include "db.php"
$sql= "select * from demo";
$res = $conn->query($sql);
?>
<table>
    <tr>
       <th>ID:</th>
       <th>Name:</th>
       <th>Age:</th>
       <th>Contact:</th>
       <th>Address:</th>
       <th>Edit:</th>
       <th>Delete:</th>
    </tr>
    <?php
    while ($row=$res->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row['id']."</td>";
        echo "<td>".$row['name']."</td>";
        echo "<td>".$row['age']."</td>";
        echo "<td>".$row['contact']."</td>";
        echo "<td><a href='edit_student.php?id=".$row['id']."'>Edit</a></td>";
        echo "<td><a href='delete_student.php?id=".$row['id']."'>delete</a></td>";
        echo "</tr>";
    }
    ?>
</table>
