<?php
include "db.php";
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];
    $gender=$_POST['gender'];
    $sql="insert into demo(name,age,contact,address,gender)
    value('$name','$age','$contact','$address','$gender')";
    echo "<pre>";
    print_r($sql);
    echo "</pre>";
    if ($conn->query($sql)==true) {
        echo "data inserted";
    }else{
        echo "data not inserted";
    }   
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <table Border="1">
        <form action="" method='post'>
            <h1>Registration Form</h1>
            <tr>
                <td>
                    <label>Name:</label>
                    <input type="text" name='name' placeholder='Enter Your Name Here' require>
                </td>
            </tr>
            <tr>
                <td>
                    <label>Age:</label>
                    <input type="text" name='age' placeholder='Enter Your age Here' require>
                </td>
            </tr>
            <tr>
                <td>
                    <label>Contact:</label>
                    <input type="text" name='contact' placeholder='Enter Your conatct Here' require>
                </td>
            </tr>
            <tr>
                <td>
                    <label>Address:</label>
                    <input type="text" name='address' placeholder='Enter Your address Here' require>
                </td>
            </tr>
            <tr>
                <td>
                    <label>Gender:</label>
                    <input type="radio" name='gender'>Male
                    <input type="radio" name='gender'>Female
                </td>
            </tr>
            <tr>
                <td>
                    <button type='submit' name="submit">Submit</button>
                </td>
            </tr>
        </form>
    </table>
</body>

</html>