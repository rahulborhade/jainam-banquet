<?php
$host='localhost';
$username='root';
$password='';
$db_name='test';
$conn = new mysqli($host,$username,$password,$db_name);
if($conn->connect_error){
echo "error";
}else{
    // echo "Great Work";
}
?>